const express = require('express');
const router = express.Router();
const Parking = require('../models/Parking');


router.get('/sugerencias', async (req, res) => {
  const query = req.query.q;
  const tipoSeleccionado = req.query.tipo;

  if (!query) return res.json([]);

  try {
    let resultados;

    if (tipoSeleccionado === 'radio-ca') {
      resultados = await Parking.find({
        CA: { $regex: query, $options: 'i' }
      }).limit(10).select('_id Nombre');

    } else if (tipoSeleccionado === 'radio-provincia') {
      resultados = await Parking.find({
        Provincia: { $regex: query, $options: 'i' }
      }).limit(10).select('_id Nombre');

    } else {
      resultados = await Parking.find({
        Nombre: { $regex: query, $options: 'i' }
      }).limit(10).select('_id Nombre');
    }

    res.json(resultados);
  } catch (err) {
    console.error('Error en búsqueda:', err);
    res.status(500).json({ error: 'Error en la búsqueda' });
  }
});


router.get('/', async (req, res) => {
  const query = req.query.q;
  const tipoSeleccionado = req.query.tipo;

  let resultados = [];
  let ccaa = [];
  let provincia = [];

  if (!query) {
    return res.render('resultadosBusqueda', {
      resultados,
      ccaa,
      provincia,
      query: '',
      tipoSeleccionado: '',
      user: req.user || null
    });
  }

  try {
    if (tipoSeleccionado === 'radio-ca') {
      resultados = await Parking.find({
        CA: { $regex: query, $options: 'i' }
      });
      ccaa =await Parking.aggregate([
        { $match: { CA: { $regex: query, $options: 'i' } } },
        { $group: { _id: "$CA", count: { $sum: 1 } } },
        { $sort: { _id: 1 } }
      ]);

    } else if (tipoSeleccionado === 'radio-provincia') {
      resultados = await Parking.find({
        Provincia: { $regex: query, $options: 'i' }
      });
      provincia = await Parking.aggregate([
        { $match: { Provincia: { $regex: query, $options: 'i' } } },
        { $group: { _id: "$Provincia", count: { $sum: 1 } } },
        { $sort: { _id: 1 } }
      ]);
    

    } else {
      resultados = await Parking.find({
        Nombre: { $regex: query, $options: 'i' }
      });
    }

    res.render('resultadosBusqueda', {
      resultados,
      ccaa,
      provincia,
      query,
      tipoSeleccionado,
      user: req.user || null
    });

  } catch (err) {
    console.error('❌ Error al buscar:', err);
    res.status(500).send('Error al buscar parkings');
  }
});



module.exports = router;
