
const express = require('express');
const router = express.Router();
const Parking = require('../models/Parking');
const User = require('../models/Users');

router.get('/', async (req, res) => {
  try {
    const parkings = await Parking.find({});

    let favoritos = [];

    if (req.user && req.user._id) {
      const favs = await User.findById(req.user._id).populate('favoritos');
      favoritos = favs.favoritos || [];
      console.log("Favoritos del usuario:", favoritos);
    }

    res.render('mapa', {
      parkings,
      favoritos,
      user: req.user || null
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error al cargar los parkings');
  }
});

module.exports = router;