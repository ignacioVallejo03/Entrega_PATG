const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const Parking = require('./models/Parking');

mongoose.connect('mongodb://localhost:27017/camperspark');

const rawData = fs.readFileSync(path.join(__dirname, 'plazas_autocaravanasDef.json'));
const parkings = JSON.parse(rawData);

async function importar() {
  try {
    await Parking.deleteMany(); // Limpieza opcional
    await Parking.insertMany(parkings);
    console.log('✅ Parkings importados correctamente');
  } catch (err) {
    console.error('❌ Error al importar:', err);
  } finally {
    mongoose.disconnect();
  }
}

importar();

