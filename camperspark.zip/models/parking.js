const mongoose = require('mongoose');

const parkingSchema = new mongoose.Schema({
  Nombre: String,
  'Tipo de Plaza': String,
  'Número de Plazas': Number,
  Dirección: String,
  Provincia: String,
  CA: String,
  Tarifa: String,
  'Pág. Reserva': String,
  Observaciones: String,
  Acceso: String,
  Latitud: Number,
  Longitud: Number,

  Servicios: mongoose.Schema.Types.Mixed,

  serviciosCercanos: {
    hospital: {
      nombre: String,
      distancia_km: Number
    },
    gasolinera: {
      nombre: String,
      distancia_km: Number
    },

    centro: {
      nombre: String,
      distancia_km: Number
    }
  }
});

module.exports = mongoose.model('Parking', parkingSchema);
