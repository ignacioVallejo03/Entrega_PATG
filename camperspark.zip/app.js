var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var app = express();
var mapaRouter = require('./routes/mapa');
var faqRouter = require('./routes/faq');
var favoritosRouter = require('./routes/favoritos');

// Se integran las dependencias de Swagger
const swaggerUi = require('swagger-ui-express') 
const swaggerFile = require('./swagger_output.json')
app.use('/doc', swaggerUi.serve, swaggerUi.setup(swaggerFile))

// Set up mongoose connection
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/camperspark')
    .then(() => console.log('Connected to MongoDB.'))
    .catch(err => console.error('Could not connect to MongoDB.', err))

// Se añaden las vistas
// Se define dónde está cada una
const loginRouter = require('./routes/login');
const signupRouter = require('./routes/signup'); 
const guiaRouter = require('./routes/guiaUso');
const parkingRoutes = require('./routes/parking');
const buscarRoutes = require('./routes/buscar');
// Se añade ultima parte
var flash = require('connect-flash');
const passport = require("./passport/setup");
const session = require("express-session");
const MongoStore = require("connect-mongo")(session);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Express Session
app.use(   
  session({
      secret: "very secret this is",
      resave: false,
      saveUninitialized: true,
      store: new MongoStore({ mongooseConnection: mongoose.connection })
  })
);

// Passport Middleware
app.use(passport.initialize()); 
app.use(passport.session()); 
app.use(flash()); 

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use("/login", loginRouter);
app.use("/signup", signupRouter);
app.use('/guiaUso', guiaRouter);
app.use('/mapa', mapaRouter);
app.use('/faq', faqRouter);
app.use('/favoritos', favoritosRouter);
app.use('/parking', parkingRoutes);
app.use('/buscar', buscarRoutes);
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
