const express = require('express');
const router = express.Router();
const User = require('../models/Users');
const Parking = require('../models/Parking');

router.get('/', async (req, res) => {
  try {
    if (!req.isAuthenticated()) return res.redirect('/login');

    const user = await User.findById(req.user._id).populate('favoritos');

    console.log("Favoritos del usuario:", user.favoritos); 

    res.render('favoritos', {
      favoritos: user.favoritos || [],
      user: req.user
    });
  } catch (err) {
    console.error('❌ Error en /favoritos:', err); 
    res.status(500).send('Error al cargar los favoritos');
  }
});


router.get('/descargar-json', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');

  try {
    const user = await User.findById(req.user._id).populate('favoritos');
    const favoritos = user.favoritos.map(p => ({
      nombre: p.Nombre,
      latitud: p.Latitud,
      longitud: p.Longitud,
      direccion: p.Dirección || '',
      provincia: p.Provincia || ''
    }));

    res.setHeader('Content-disposition', 'attachment; filename=favoritos.json');
    res.setHeader('Content-type', 'application/json');
    res.write(JSON.stringify(favoritos, null, 2));
    res.end();
  } catch (err) {
    console.error('❌ Error exportando JSON:', err);
    res.status(500).send('Error generando el archivo');
  }
});

router.post('/add', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');

  try {
    const { parkingId } = req.body;
    const user = await User.findById(req.user._id);

    if (!user.favoritos.includes(parkingId)) {
      user.favoritos.push(parkingId);
      await user.save();
    }

    res.redirect('/favoritos');
  } catch (err) {
    console.error('Error al añadir favorito:', err);
    res.status(500).send('Error al añadir a favoritos');
  }
});

router.post('/remove', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');

  try {
    const { parkingId } = req.body;

    await User.findByIdAndUpdate(req.user._id, {
      $pull: { favoritos: parkingId }
    });

    res.redirect('/favoritos');
  } catch (err) {
    console.error('Error al quitar favorito:', err);
    res.status(500).send('Error al quitar favorito');
  }
});

module.exports = router;
