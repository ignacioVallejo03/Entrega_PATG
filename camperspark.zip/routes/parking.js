const express = require('express');
const router = express.Router();
const Parking = require('../models/Parking');
const User = require('../models/Users');

router.get('/:id', async (req, res) => {
  try {
    const parking = await Parking.findById(req.params.id);
    
    let favoritos = [];
    if (!parking) {
      return res.status(404).send('Parking no encontrado');
    }
    if (req.user && req.user._id) {
      const favs = await User.findById(req.user._id).populate('favoritos');
      favoritos = favs.favoritos || [];
      console.log("Favoritos del usuario:", favoritos);
    }
    res.render('parkingDetalle', {
      parking,
      favoritos,
      user: req.user || null
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error al cargar el detalle del parking');
  }
});

module.exports = router;
