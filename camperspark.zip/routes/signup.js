var express = require('express');
var router = express.Router();
const passport = require("passport");
const User = require('../models/Users');

	router.get('/', (req, res) => {
		res.render('signup', {
			message: req.flash('signupMessage')
		});
	});

	router.post('/', passport.authenticate('local-signup', {
		successRedirect: '/',
		failureRedirect: '/signup',
		failureFlash: true
	}));
	
module.exports = router;