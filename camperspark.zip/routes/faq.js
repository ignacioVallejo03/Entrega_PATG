var express = require('express');
var router = express.Router();

// Ruta para la vista FAQ
router.get('/', (req, res) => {
    res.render('faq.ejs', {
        user: req.user || null // Pasamos user para evitar errores en el header
    });
});

module.exports = router;
