var express = require('express');
var o2x = require('object-to-xml');
var router = express.Router();

// Conexión Mongo
 
var mongoose = require('mongoose');
var ObjectId = mongoose.Types.ObjectId;


function isLoggedIn (req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/login');
}


router.get('/', async (req, res, next) => {
  
  res.render('index', { title: 'CampersPark page', user: req.user });  
});



router.get('/logout', (req, res, next) => {
  req.logout(function(err) {
    if (err) return next(err);
    res.redirect('/login'); // O a la página que quieras después de cerrar sesión
  });
});

module.exports = router;
