const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const Parking = require('./models/parking');

// Read and parse GeoJSON
const geojson = JSON.parse(fs.readFileSync(path.join(__dirname, 'EESS.geojson')));

if (!geojson.features || !Array.isArray(geojson.features)) {
  throw new Error('The GeoJSON file does not contain a valid "features" array.');
}

const gasolineras = geojson.features;

// Función para calcular distancia entre dos coordenadas (Haversine)
function calcularDistanciaKm(lat1, lon1, lat2, lon2) {
  const R = 6371; // radio Tierra km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Script principal
async function main() {
  try {
    await mongoose.connect('mongodb://localhost:27017/camperspark'); // Cambia la URI si es distinta
    console.log('✅ Conectado a MongoDB');

    const parkings = await Parking.find({});
    console.log(`🚐 Encontrados ${parkings.length} parkings`);

    for (const parking of parkings) {
      const latP = parking.Latitud;
      const lonP = parking.Longitud;

      if (!latP || !lonP) continue;

      let distanciaMin = Infinity;
      let nombreGasolinera = null;

      for (const g of gasolineras) {
        // Check if the coordinates are valid and skip any invalid ones
        if (!g.geometry || !Array.isArray(g.geometry.coordinates) || g.geometry.coordinates.length < 2) {
          continue; // Skip invalid gas stations
        }

        // Only use the first two values from the coordinates array (longitude, latitude)
        const [lngG, latG] = g.geometry.coordinates.slice(0, 2);
        const dist = calcularDistanciaKm(latP, lonP, latG, lngG);

        if (dist < distanciaMin) {
          distanciaMin = dist;
          nombreGasolinera = g.properties.Rotulo || 'Gasolinera desconocida';
        }
      }

      const distanciaRedondeada = parseFloat(distanciaMin.toFixed(2));

      if (!parking.serviciosCercanos) parking.serviciosCercanos = {};

      parking.serviciosCercanos.gasolinera = {
        distancia_km: distanciaRedondeada,
        nombre: nombreGasolinera
      };

      await parking.save();
      console.log(`✅ ${parking.Nombre} → ${distanciaRedondeada} km (${nombreGasolinera})`);
    }

    console.log('🎉 Todas las distancias a gasolineras actualizadas');
    process.exit();
  } catch (err) {
    console.error('❌ Error:', err);
    process.exit(1);
  }
}

main();
