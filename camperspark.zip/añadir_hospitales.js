const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const Parking = require('./models/parking'); // ajusta si tu modelo está en otra ruta

// Cargar el GeoJSON de hospitales
const hospitales = JSON.parse(fs.readFileSync(path.join(__dirname, 'xn--Hospitales_de_Espaa-d4b.geojson'))).features;

// Función para calcular distancia entre dos coordenadas
function calcularDistanciaKm(lat1, lon1, lat2, lon2) {
  const R = 6371; // radio de la Tierra en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Conectar a MongoDB
mongoose.connect('mongodb://localhost:27017/camperspark', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  console.log('✅ Conectado a MongoDB');

  const parkings = await Parking.find();

  for (const parking of parkings) {
    const { Latitud, Longitud } = parking;
    if (!Latitud || !Longitud) continue;

    let hospitalMasCercano = null;
    let distanciaMin = Infinity;

    hospitales.forEach(hospital => {
      const [lon, lat] = hospital.geometry.coordinates;
      const distancia = calcularDistanciaKm(Latitud, Longitud, lat, lon);

      if (distancia < distanciaMin) {
        distanciaMin = distancia;
        hospitalMasCercano = {
          nombre: hospital.properties.NOMBRE,
          direccion: hospital.properties.DIRECCION,
          distancia_km: parseFloat(distancia.toFixed(2))
        };
      }
    });

    if (hospitalMasCercano) {
      parking.serviciosCercanos = parking.serviciosCercanos || {};
      parking.serviciosCercanos.hospital = hospitalMasCercano;
      await parking.save();
      console.log(`✅ ${parking.Nombre}: ${hospitalMasCercano.nombre} a ${hospitalMasCercano.distancia_km} km`);
    }
  }

  console.log('✅ Actualización completa');
  mongoose.disconnect();
}).catch(err => {
  console.error('❌ Error:', err);
});
